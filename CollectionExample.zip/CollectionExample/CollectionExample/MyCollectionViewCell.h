//
//  MyCollectionViewCell.h
//  CollectionExample
//
//  Created by Aravindakumar Arunachalam on 26/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *ImgCell;
@property (weak, nonatomic) IBOutlet UILabel *lblCell;

@end
