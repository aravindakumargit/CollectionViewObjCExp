//
//  ViewController.m
//  CollectionExample
//
//  Created by Aravindakumar Arunachalam on 26/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
    NSMutableArray *arr;
    NSMutableArray *countryArr;
    NSMutableArray *flagArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   countryArr=[[NSMutableArray alloc]init];
    flagArr=[[NSMutableArray alloc]init];
        [self jsonFetch];
    //[self hitserver];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
return [countryArr count];}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MyCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    MyCollectionViewCell *tempCell=(MyCollectionViewCell *)cell;
    //without lazyloading
//       NSURL *url = [NSURL URLWithString:[flagArr objectAtIndex:indexPath.row]];
//     NSDate *data = [[NSData alloc]initWithContentsOfURL:url];
//        UIImage *img = [[UIImage alloc]initWithData:data ];
//        tempCell.ImgCell.image =img;
        tempCell.lblCell.text=[NSString stringWithFormat:@"%@",[countryArr objectAtIndex:indexPath.row]];
    //with lazyloading
    [tempCell.ImgCell setImageWithURL:[NSURL URLWithString:[flagArr objectAtIndex:indexPath.row]] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
 
    

    return cell;
}
-(void)jsonFetch{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    NSString *urlStr=@"http://www.androidbegin.com/tutorial/jsonparsetutorial.txt";
    [request setURL:[NSURL URLWithString:urlStr]];
    [request setHTTPMethod:@"GET"];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        NSDictionary* responseJson = [NSJSONSerialization JSONObjectWithData:data
                                                             options:kNilOptions
                                                               error:&error];
        
        NSLog(@"Request reply: %@", responseJson);
        NSArray *worldpopulationArr = [[NSArray alloc]initWithArray:[responseJson objectForKey:@"worldpopulation"]];
         dispatch_async(dispatch_get_main_queue(),^{
        for(int i=0;i<worldpopulationArr.count;i++){
            NSString *country =[[worldpopulationArr objectAtIndex:i]objectForKey:@"country"];
            [countryArr addObject:country];
            NSString *flag =[[worldpopulationArr objectAtIndex:i]objectForKey:@"flag"];
            [flagArr addObject:flag];
            
        }
       
            [self.CollectionView reloadData];

                    });
            }]
     resume];
    

    
}
-(void)hitserver{
    NSURL *url =[NSURL URLWithString:@"http://www.androidbegin.com/tutorial/jsonparsetutorial.txt"];//here string is converted to url
    NSDate *data =[NSData dataWithContentsOfURL:url];//here url converted to data
    NSDictionary *responseJson =[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    
    
    NSLog(@"Request reply: %@", responseJson);
    NSArray *worldpopulationArr = [[NSArray alloc]initWithArray:[responseJson objectForKey:@"worldpopulation"]];
    for(int i=0;i<worldpopulationArr.count;i++){
        NSString *country =[[worldpopulationArr objectAtIndex:i]objectForKey:@"country"];
        [countryArr addObject:country];
        NSString *flag =[[worldpopulationArr objectAtIndex:i]objectForKey:@"flag"];
        [flagArr addObject:flag];

}
}
@end
