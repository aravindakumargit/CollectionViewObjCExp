//
//  MyCollectionViewCell.m
//  CollectionExample
//
//  Created by Aravindakumar Arunachalam on 26/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

#import "MyCollectionViewCell.h"

@implementation MyCollectionViewCell

@end
