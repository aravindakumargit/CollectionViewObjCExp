//
//  ViewController.h
//  CollectionExample
//
//  Created by Aravindakumar Arunachalam on 26/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyCollectionViewCell.h"
#import "UIImageView+WebCache.h"

@interface ViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (weak, nonatomic) IBOutlet UILabel *textlbl;
@property (weak, nonatomic) IBOutlet UICollectionView *CollectionView;

@end

